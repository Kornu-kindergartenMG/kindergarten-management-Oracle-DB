package parent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import parent.parentVO;
import kid.kidVO;
import teacher.teacherVO;

public class parentDAO {
    /**
     * 필요한 property 선언
     */
    Connection con;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
    //ORACLE
    String driverName="oracle.jdbc.OracleDriver";
    String url = "jdbc:oracle:thin:@localhost:1521:XE";
    String id = "yk";
    String pwd ="1234";
    /**
     * 로드와 연결을 위한 생성자 작성
     */
    public parentDAO(){
        try {
            //로드
            Class.forName(driverName);
            //연결
            con = DriverManager.getConnection(url,id,pwd);      
        
        	} catch (ClassNotFoundException e) {
        	System.out.println(e+"=> 로드 실패");
        	
        	} catch (SQLException e) {
            System.out.println(e+"=> 연결 실패");
            }


    		}//parentDAO()
    /**
     * DB닫기 기능 메소드 작성
     */
    public void db_close(){

    	try {
            if (rs != null ) rs.close();
            if (ps != null ) ps.close();      
            if (st != null ) st.close();
        	} 
        catch (SQLException e) {
            System.out.println(e+"=> 닫기 오류");
            }      
        
    } //db_close


    /**
      * parent테이블에 insert하는 메소드 작성
      */
    public int parentInsert(parentVO vo){
        int result = 0;

        try{
        //실행
            String sql = "INSERT INTO PARENT VALUES(?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, vo.getp_Id());
            ps.setString(2, vo.getp_Pwd());
            ps.setString(3, vo.getp_Name());
            ps.setString(4, vo.getp_Phone());
            ps.setString(5, vo.getp_Ju1());
            ps.setString(6, vo.getp_Ju2());
            ps.setString(7, vo.getp_Eml());
            ps.setString(8, vo.getp_Ad());

            result = ps.executeUpdate();
            }
        catch (Exception e){
            System.out.println(e + "=> parentInsert fail");
            }
        finally{
            db_close();
            }
        return result;
    }//parentInsert
    
           
    /**
     * parent테이블의 모든 레코드 검색하(Select)는 메서드 작성
     * (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
     **/
    public ArrayList<parentVO> getparentlist(String keyField, String keyWord){
        ArrayList<parentVO> list = new ArrayList<parentVO>();
        try{//실행
            String sql ="select * from PARENT ";
            if(keyWord != null && !keyWord.equals("") ){
                sql +="WHERE "+keyField.trim()+" LIKE '%"+keyWord.trim()+"%' order by p_Id";
            }else{//모든 레코드 검색
                sql +="order by p_Name";
            }
            System.out.println("sql = " + sql);
            st = con.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                parentVO vo = new parentVO();
                vo.setp_Id(rs.getString(1));
                vo.setp_Pwd(rs.getString(2));
                vo.setp_Name(rs.getString(3));
                vo.setp_Phone(rs.getString(4));
                vo.setp_Ju1(rs.getString(5));
                vo.setp_Ju2(rs.getString(6));
                vo.setp_Eml(rs.getString(7));
                vo.setp_Ad(rs.getString(8));
                
                list.add(vo);
            }
        }catch(Exception e){           
            System.out.println(e+"=> getParentSearchlist fail");         
        }finally{          
            db_close();
        }      
        return list;
    }//getparentSearchlist

    
    
    
    /**
     * parent테이블의 모든 레코드 검색하(Select)는 메서드 작성
     */   
    public ArrayList<parentVO> getparentlist(){
        ArrayList<parentVO> list = new ArrayList<parentVO>();
        try{//실행
            st = con.createStatement();
            rs = st.executeQuery("select * from PARENT");
            while(rs.next()){
            	parentVO vo = new parentVO();
                vo.setp_Id(rs.getString(1));
                vo.setp_Pwd(rs.getString(2));
                vo.setp_Name(rs.getString(3));
                vo.setp_Phone(rs.getString(4));
                vo.setp_Ju1(rs.getString(5));
                vo.setp_Ju2(rs.getString(6));
                vo.setp_Eml(rs.getString(7));
                vo.setp_Ad(rs.getString(8));
                
                list.add(vo);
            }
        }catch(Exception e){          
            System.out.println(e+"=> getparentlist fail");        
        }finally{          
            db_close();
        }      
        return list;
    }//getparentlist

    /**
     * parent테이블의 p_Id 값 찾는 메서드 작성
     */   
    public ArrayList<parentVO> getparentdelete(){
        ArrayList<parentVO> list = new ArrayList<parentVO>();
        try{//실행
            st = con.createStatement();
            rs = st.executeQuery("select p_Id from PARENT");
            while(rs.next()){
            	parentVO vo = new parentVO();
                vo.setp_Id(rs.getString(1));
                
                list.add(vo);
            }
        }catch(Exception e){          
            System.out.println(e+"=> getparentp_Id fail");        
        }finally{          
            db_close();
        }      
        return list;
    }//getparentp_Id
 
/**
 * parent테이블의 ID에 해당하는 레코드 삭제
 */
public int delparentlist(String id){
    int result = 0;
    try{//실행
        ps = con.prepareStatement("delete from PARENT where p_Id = ?");
        //?개수만큼 값 지정
        ps.setString(1,id.trim());
        result = ps.executeUpdate(); //쿼리실행으로 삭제된 레코드 수 반환       
    }catch(Exception e){           
        System.out.println(e+"=> delparentlist fail");         
    }finally{          
        db_close();
    }      
    return result;
}



}