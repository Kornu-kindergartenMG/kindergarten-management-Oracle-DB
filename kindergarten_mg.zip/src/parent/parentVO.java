package parent;
/*
 *
 * * Parent에 해당하는 정보에 대한 저장소 역할
	 *
	 */
public class parentVO {
	/**
	 * 필요한 property 선언
	 */
	    private String p_id;
	    private String p_pwd;
	    private String p_name;
	    private String p_phone;
		private String p_ju1;
	    private String p_ju2;
	    private String p_eml;
	    private String p_ad;
		
	    public parentVO(){}
	    public parentVO(String p_id, String p_pwd, String p_name, 
	    		String p_phone,String p_ju1, String p_ju2,
	    		String p_eml,String p_ad ){
	       
	        this.p_id = p_id;
	        this.p_pwd = p_pwd;
	        this.p_name = p_name;
	        this.p_phone = p_phone;
	        
	        this.p_ju1 = p_ju1;
	        this.p_ju2 = p_ju2;
	        this.p_eml = p_eml;
	        this.p_ad = p_ad;
	    }
	   
	  
	    public String getp_Id() {
	        return p_id;
	    }
	    public void setp_Id(String p_id) {
	        this.p_id = p_id;
	    }
	    public String getp_Pwd() {
	        return p_pwd;
	    }
	    public void setp_Pwd(String p_pwd) {
	        this.p_pwd = p_pwd;
	    }
	    public String getp_Name() {
	        return p_name;
	    }
	    public void setp_Name(String p_name) {
	        this.p_name = p_name;
	    }
	    public String getp_Phone() {
	        return p_phone;
	    }
	    public void setp_Phone(String p_phone) {
	        this.p_phone = p_phone;
	    }
	    public String getp_Ju1() {
	        return p_ju1;
	    }
	    public void setp_Ju1(String p_ju1) {
	        this.p_ju1 = p_ju1;
	    }
	    public String getp_Ju2() {
	        return p_ju2;
	    }
	    public void setp_Ju2(String p_ju2) {
	        this.p_ju2 = p_ju2;
	    }
	    public String getp_Eml() {
	        return p_eml;
	    }
	    public void setp_Eml(String p_eml) {
	        this.p_eml = p_eml;
	    }
	    public String getp_Ad() {
	        return p_ad;
	    }
	    public void setp_Ad(String p_ad) {
	        this.p_ad = p_ad;
	    }	   
}
