package teacher;
/*
 *
 * * kid에 해당하는 정보에 대한 저장소 역할
	 *
	 */
public class teacherVO {
	/**
	 * 필요한 property 선언
	 */
	    private String t_name;
	    private String t_posi;
	    private String t_kclass;
	    private String t_phone;
	    private String t_salary;
	    
	    public teacherVO(){}
	    public teacherVO(String t_name, String t_posi, String t_kclass, 
	    		String t_phone, String t_salary){
	       
	        this.t_name = t_name;
	        this.t_posi = t_posi;
	        
	        this.t_kclass = t_kclass;
	        this.t_phone  = t_phone;
	        this.t_salary = t_salary;
	        
	    }
	   
	   
	    public String gett_Name() {
	        return t_name;
	    }
	    public void sett_Name(String t_name) {
	        this.t_name = t_name;
	    }
	    public String gett_Posi() {
	        return t_posi;
	    }
	    public void sett_Posi(String t_posi) {
	        this.t_posi = t_posi;
	    }
	    public String gett_Kclass() {
	        return t_kclass;
	    }
	    public void sett_Kclass(String t_kclass) {
	        this.t_kclass = t_kclass;
	    }
	    public String gett_Phone() {
	        return t_phone;
	    }
	    public void sett_Phone(String t_phone) {
	        this.t_phone = t_phone;
	    }
	    public String gett_Salary() {
	        return t_salary;
	    }
	    public void sett_Salary(String t_salary) {
	        this.t_salary= t_salary;
	    }	 
}
