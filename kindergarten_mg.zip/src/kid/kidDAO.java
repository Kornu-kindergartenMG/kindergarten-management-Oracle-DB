package kid;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
 
import kid.kidVO;
import parent.parentVO;
 
public class kidDAO {
 
    /**
     * 필요한 property 선언
     */
    Connection con;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
   
    //ORACLE
    String driverName="oracle.jdbc.OracleDriver";
    String url = "jdbc:oracle:thin:@localhost:1521:XE";
    String id = "yk";
    String pwd ="1234";

    /**
     * 로드와 연결을 위한 생성자 작성
     */
    public kidDAO(){
       
        try {
            //로드
            Class.forName(driverName);
           
            //연결
            con = DriverManager.getConnection(url,id,pwd);      
           
        } catch (ClassNotFoundException e) {
           
            System.out.println(e+"=> 로드 실패");
           
        } catch (SQLException e) {
           
            System.out.println(e+"=> 연결 실패");
        }
    }//parentDAO()
   
    /**
     * DB닫기 기능 메소드 작성
     */
    public void db_close(){
       
        try {
           
            if (rs != null ) rs.close();
            if (ps != null ) ps.close();      
            if (st != null ) st.close();
       
        } catch (SQLException e) {
            System.out.println(e+"=> 닫기 오류");
        }      
       
    } //db_close
   
    /**
     * kid테이블에 insert하는 메소드 작성
     */
    public int kidInsert(kidVO vo){
        int result = 0;
       
        try{
        //실행
            String sql = "INSERT INTO KID VALUES(?,?,?,?,?,?,?,?,?)";
           
            ps = con.prepareStatement(sql);
            ps.setString(1, vo.getk_Name());
            ps.setString(2, vo.getk_Age());
            ps.setString(3, vo.getk_Gender());
            ps.setString(4, vo.getk_Ju1());
            ps.setString(5, vo.getk_Ju2());
            ps.setString(6, vo.getk_Phone());
            ps.setString(7, vo.getk_Tclass());
            ps.setString(8, vo.getk_Infor());
            ps.setString(9, vo.getk_Pju2());
            
            result = ps.executeUpdate();
           
        }catch (Exception e){
           
            System.out.println(e + "=> KidInsert fail");
           
        }finally{
            db_close();
        }
       
        return result;
    }//KidInsert

    
    /**
     * kid테이블의 모든 레코드 검색하(Select)는 메서드 작성
     * (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
     **/
    public ArrayList<kidVO> getkidlist(String keyField, String keyWord){
        ArrayList<kidVO> list1 = new ArrayList<kidVO>();
        try{//실행
            String sql ="select * from KID ";
            if(keyWord != null && !keyWord.equals("") ){
                sql +="WHERE "+keyField.trim()+" LIKE '%"+keyWord.trim()+"%' order by k_Name";
            }else{//모든 레코드 검색
                sql +="order by k_Name";
            }
            System.out.println("sql = " + sql);
            st = con.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                kidVO vo = new kidVO();
                vo.setk_Name(rs.getString(1));
                vo.setk_Age(rs.getString(2));
                vo.setk_Gender(rs.getString(3));
                vo.setk_Ju1(rs.getString(4));
                vo.setk_Ju2(rs.getString(5));
                vo.setk_Phone(rs.getString(6));
                vo.setk_Tclass(rs.getString(7));
                vo.setk_Infor(rs.getString(8));
                vo.setk_Pju2(rs.getString(9));
                
                list1.add(vo);
            }
        }catch(Exception e){           
            System.out.println(e+"=> getkidlist1 fail");         
        }finally{          
            db_close();
        }      
        return list1;
    }//getkidSearchlist

    
    
    
    
    /**
     * kid테이블의 모든 레코드 검색하(Select)는 메서드 작성
     */   
    public ArrayList<kidVO> getkidlist(){
       
        ArrayList<kidVO> list = new ArrayList<kidVO>();
       
        try{//실행
            st = con.createStatement();
            rs = st.executeQuery("select * from KID");
           
            while(rs.next()){
            	kidVO vo = new kidVO();
               
                vo.setk_Name(rs.getString(1));
                vo.setk_Age(rs.getString(2));
                vo.setk_Gender(rs.getString(3));
                vo.setk_Ju1(rs.getString(4));
                vo.setk_Ju2(rs.getString(5));
                vo.setk_Phone(rs.getString(6));
                vo.setk_Tclass(rs.getString(7));
                vo.setk_Infor(rs.getString(8));
                vo.setk_Pju2(rs.getString(9));
                
                list.add(vo);
            }
        }catch(Exception e){          
            System.out.println(e+"=> getKidlist fail");        
        }finally{          
            db_close();
        }      
        return list;
    }//getKidlist
   
    
/**
 * kid테이블의 ID에 해당하는 레코드 삭제
 */
public int delkidlist(String id){
    int result = 0;
    try{//실행
        ps = con.prepareStatement("delete from KID where k_Name = ?");
        //?개수만큼 값 지정
        ps.setString(1,id.trim());
        result = ps.executeUpdate(); //쿼리실행으로 삭제된 레코드 수 반환       
    }catch(Exception e){           
        System.out.println(e+"=> delkidlist fail");         
    }finally{          
        db_close();
    }      
    return result;
}





/**
 * kid테이블의 서브쿼리를 이용하여 아동 '?'와 같은 반인 아동의 이름을 검색하(Select)는 메서드 작성
 * (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
 **/
public ArrayList<kidVO> getkidlist2(String keyField, String keyWord){
    ArrayList<kidVO> list2 = new ArrayList<kidVO>();
    try{//실행
        String sql ="select k_Tclass, k_Name "
        		+ "from KID where k_Tclass = "
        		+ "(select k_Tclass from KID where k_Name=? ";
        if(keyWord != null && !keyWord.equals("") ){
            sql +="WHERE "+keyField.trim()+" LIKE '%"+keyWord.trim()+"%' order by k_Name";
        }else{//모든 레코드 검색
            sql +="order by k_Name";
        }
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
            kidVO vo = new kidVO();
            vo.setk_Gender(rs.getString(1));
            vo.setk_Name(rs.getString(2));
            
            list2.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getkidlist2 fail");         
    }finally{          
        db_close();
    }      
    return list2;
}//getkidSearchlist 서브쿼리를 이용하여 아동 '?'와 같은 반인 아동의 이름을 검색









    
}
 