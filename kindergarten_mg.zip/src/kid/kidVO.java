package kid;
/*
 *
 * * kid에 해당하는 정보에 대한 저장소 역할
	 *
	 */
public class kidVO {
	/**
	 * 필요한 property 선언
	 */
	    private String k_name;
	    private String k_age;
		private String k_gender;
	    private String k_ju1;
	    private String k_ju2;
	    private String k_phone;
	    private String k_tclass;
	    private String k_infor;
	    private String k_pju2;
	    
	    public kidVO(){}
	    public kidVO(String k_name, String k_age, String k_gender, 
	    		String k_ju1, String k_ju2, String k_phone, String k_tclass,
	    		String k_infor, String k_pju2){
	       
	        this.k_name = k_name;
	        this.k_age = k_age;
	        this.k_gender = k_gender;
	        
	        this.k_ju1 = k_ju1;
	        this.k_ju2 = k_ju2;
	        this.k_phone = k_phone;
	       
	        this.k_tclass = k_tclass;
	        this.k_infor = k_infor;
	        this.k_pju2 = k_pju2;
	        
	       }
	   
	   
	    public String getk_Name() {
	        return k_name;
	    }
	    public void setk_Name(String k_name) {
	        this.k_name = k_name;
	    }
	    public String getk_Age() {
	        return k_age;
	    }
	    public void setk_Age(String k_age) {
	        this.k_age = k_age;
	    }
	    public String getk_Gender() {
	        return k_gender;
	    }
	    public void setk_Gender(String k_gender) {
	        this.k_gender = k_gender;
	    }
	    public String getk_Ju1() {
	        return k_ju1;
	    }
	    public void setk_Ju1(String k_ju1) {
	        this.k_ju1 = k_ju1;
	    }
	    public String getk_Ju2() {
	        return k_ju2;
	    }
	    public void setk_Ju2(String k_ju2) {
	        this.k_ju2= k_ju2;
	    }
	    public String getk_Phone() {
	        return k_phone;
	    }
	    public void setk_Phone(String k_phone) {
	        this.k_phone = k_phone;
	    }
	    public String getk_Tclass() {
	        return k_tclass;
	    }
	    public void setk_Tclass(String k_tclass) {
	        this.k_tclass = k_tclass;
	    }
	    public String getk_Infor() {
	        return k_infor;
	    }
	    public void setk_Infor(String k_infor) {
	        this.k_infor = k_infor;
	    }
	    public String getk_Pju2() {
	        return k_pju2;
	    }
	    public void setk_Pju2(String k_pju2) {
	        this.k_pju2 = k_pju2;
	    }
}
