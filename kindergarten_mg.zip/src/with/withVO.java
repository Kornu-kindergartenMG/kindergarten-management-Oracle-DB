package with;
/*
 *
 * * Parent에 해당하는 정보에 대한 저장소 역할
	 *
	 */
public class withVO {
	/**
	 * 필요한 property 선언
	 */
	    private String p_id;
	    private String p_pwd;
	    private String p_name;
	    private String p_phone;
		private String p_ju1;
	    private String p_ju2;
	    private String p_eml;
	    private String p_ad;

	    private String k_name;
	    private String k_age;
	    
	    private String k_age_max;
	    
		private String k_gender;
	    private String k_ju1;
	    private String k_ju2;
	    private String k_phone;
	    private String k_tclass;
	    private String k_infor;
	    private String k_pju2;

	    private String t_name;
	    private String t_posi;
	    private String t_kclass;
	    private String t_phone;
	    private String t_salary;

	    
	    public withVO(){}
	    public withVO(String p_id, String p_pwd, String p_name, 
	    		String p_phone,String p_ju1, String p_ju2,
	    		String p_eml,String p_ad,
	    		
	    		String k_name, String k_age, String k_age_max,String k_gender, 
	    		String k_ju1, String k_ju2, String k_phone, String k_tclass,
	    		String k_infor, String k_pju2, String t_name,
	    		
	    		String t_posi, String t_kclass, 
	    		String t_phone, String t_salary ){
	       
	        this.p_id = p_id;
	        this.p_pwd = p_pwd;
	        this.p_name = p_name;
	        this.p_phone = p_phone;
	        this.p_ju1 = p_ju1;
	        this.p_ju2 = p_ju2;
	        this.p_eml = p_eml;
	        this.p_ad = p_ad;

	        this.k_name = k_name;
	        this.k_age = k_age;

	        this.k_age_max = k_age_max;
	        
	        this.k_gender = k_gender;
	        this.k_ju1 = k_ju1;
	        this.k_ju2 = k_ju2;
	        this.k_phone = k_phone;
	        this.k_tclass = k_tclass;
	        this.k_infor = k_infor;
	        this.k_pju2 = k_pju2;
	        
	        this.t_name = t_name;
	        this.t_posi = t_posi;
	        this.t_kclass = t_kclass;
	        this.t_phone  = t_phone;
	        this.t_salary = t_salary;

	    }
	   
	  
	    public String getp_Id() {
	        return p_id;
	    }
	    public void setp_Id(String p_id) {
	        this.p_id = p_id;
	    }
	    public String getp_Pwd() {
	        return p_pwd;
	    }
	    public void setp_Pwd(String p_pwd) {
	        this.p_pwd = p_pwd;
	    }
	    public String getp_Name() {
	        return p_name;
	    }
	    public void setp_Name(String p_name) {
	        this.p_name = p_name;
	    }
	    public String getp_Phone() {
	        return p_phone;
	    }
	    public void setp_Phone(String p_phone) {
	        this.p_phone = p_phone;
	    }
	    public String getp_Ju1() {
	        return p_ju1;
	    }
	    public void setp_Ju1(String p_ju1) {
	        this.p_ju1 = p_ju1;
	    }
	    public String getp_Ju2() {
	        return p_ju2;
	    }
	    public void setp_Ju2(String p_ju2) {
	        this.p_ju2 = p_ju2;
	    }
	    public String getp_Eml() {
	        return p_eml;
	    }
	    public void setp_Eml(String p_eml) {
	        this.p_eml = p_eml;
	    }
	    public String getp_Ad() {
	        return p_ad;
	    }
	    public void setp_Ad(String p_ad) {
	        this.p_ad = p_ad;
	    }	   
	    
	    public String getk_Name() {
	        return k_name;
	    }
	    public void setk_Name(String k_name) {
	        this.k_name = k_name;
	    }
	    public String getk_Age() {
	        return k_age;
	    }
	    public void setk_Age(String k_age) {
	        this.k_age = k_age;
	    }
	    
	    public String getk_Age_max() {
	        return k_age_max;
	    }
	    public void setk_Age_max(String k_age_max) {
	        this.k_age_max = k_age_max;
	    }

	    
	    public String getk_Gender() {
	        return k_gender;
	    }
	    public void setk_Gender(String k_gender) {
	        this.k_gender = k_gender;
	    }
	    public String getk_Ju1() {
	        return k_ju1;
	    }
	    public void setk_Ju1(String k_ju1) {
	        this.k_ju1 = k_ju1;
	    }
	    public String getk_Ju2() {
	        return k_ju2;
	    }
	    public void setk_Ju2(String k_ju2) {
	        this.k_ju2= k_ju2;
	    }
	    public String getk_Phone() {
	        return k_phone;
	    }
	    public void setk_Phone(String k_phone) {
	        this.k_phone = k_phone;
	    }
	    public String getk_Tclass() {
	        return k_tclass;
	    }
	    public void setk_Tclass(String k_tclass) {
	        this.k_tclass = k_tclass;
	    }
	    public String getk_Infor() {
	        return k_infor;
	    }
	    public void setk_Infor(String k_infor) {
	        this.k_infor = k_infor;
	    }
	    public String getk_Pju2() {
	        return k_pju2;
	    }
	    public void setk_Pju2(String k_pju2) {
	        this.k_pju2 = k_pju2;
	    }
	    
	    
	    public String gett_Name() {
	        return t_name;
	    }
	    public void sett_Name(String t_name) {
	        this.t_name = t_name;
	    }
	    public String gett_Posi() {
	        return t_posi;
	    }
	    public void sett_Posi(String t_posi) {
	        this.t_posi = t_posi;
	    }
	    public String gett_Kclass() {
	        return t_kclass;
	    }
	    public void sett_Kclass(String t_kclass) {
	        this.t_kclass = t_kclass;
	    }
	    public String gett_Phone() {
	        return t_phone;
	    }
	    public void sett_Phone(String t_phone) {
	        this.t_phone = t_phone;
	    }
	    public String gett_Salary() {
	        return t_salary;
	    }
	    public void sett_Salary(String t_salary) {
	        this.t_salary= t_salary;
	    }	 
	    
	    
}
