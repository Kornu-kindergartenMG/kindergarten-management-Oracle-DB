package with;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import parent.parentVO;
import kid.kidVO;
import teacher.teacherVO;

public class withDAO {
    /**
     * 필요한 property 선언
     */
    Connection con;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
    //ORACLE
    String driverName="oracle.jdbc.OracleDriver";
    String url = "jdbc:oracle:thin:@localhost:1521:XE";
    String id = "yk";
    String pwd ="1234";
    /**
     * 로드와 연결을 위한 생성자 작성
     */
    public withDAO(){
        try {
            //로드
            Class.forName(driverName);
            //연결
            con = DriverManager.getConnection(url,id,pwd);      
        
        	} catch (ClassNotFoundException e) {
        	System.out.println(e+"=> 로드 실패");
        	
        	} catch (SQLException e) {
            System.out.println(e+"=> 연결 실패");
            }


    		}//parentDAO()
    /**
     * DB닫기 기능 메소드 작성
     */
    public void db_close(){

    	try {
            if (rs != null ) rs.close();
            if (ps != null ) ps.close();      
            if (st != null ) st.close();
        	} 
        catch (SQLException e) {
            System.out.println(e+"=> 닫기 오류");
            }      
        
    } //db_close


           
    /**
     * 모든 테이블의 모든 레코드 검색하(Select)는 메서드 작성
     * (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
     **/
    public ArrayList<withVO> getwithlist(){
        ArrayList<withVO> list = new ArrayList<withVO>();
        try{//실행
            String sql ="select * "
            		+ "from PARENT,KID,TEACHER ";
            //모든 레코드 검색
                sql +="order by p_Id";
            
            System.out.println("sql = " + sql);
            st = con.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                withVO vo = new withVO();
                vo.setp_Id(rs.getString(1));
                vo.setp_Pwd(rs.getString(2));
                vo.setp_Name(rs.getString(3));
                vo.setp_Phone(rs.getString(4));
                vo.setp_Ju1(rs.getString(5));
                vo.setp_Ju2(rs.getString(6));
                vo.setp_Eml(rs.getString(7));
                vo.setp_Ad(rs.getString(8));
                
                vo.setk_Name(rs.getString(9));
                vo.setk_Age(rs.getString(10));
                vo.setk_Gender(rs.getString(11));
                vo.setk_Ju1(rs.getString(12));
                vo.setk_Ju2(rs.getString(13));
                vo.setk_Phone(rs.getString(14));
                vo.setk_Tclass(rs.getString(15));
                vo.setk_Infor(rs.getString(16));
                vo.setk_Pju2(rs.getString(17));

                vo.sett_Name(rs.getString(18));
                vo.sett_Posi(rs.getString(19));
                vo.sett_Kclass(rs.getString(20));
                vo.sett_Phone(rs.getString(21));
                vo.sett_Salary(rs.getString(22));

  
                list.add(vo);
            }
        }catch(Exception e){           
            System.out.println(e+"=> getwithSearchlist fail");         
        }finally{          
            db_close();
        }      
        return list;
    }//getwithSearchlist

    





/**
* 서브쿼리로, 직급인 '교사'인 선생님의 급여를 검색하는 메서드 작성
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist1(){
    ArrayList<withVO> list1 = new ArrayList<withVO>();
    try{//실행
        String sql ="select t_Name, t_Posi, t_Salary from TEACHER where t_Salary IN (select t_Salary from TEACHER where t_Posi ='교사') ";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.sett_Name(rs.getString(1));
            vo.sett_Posi(rs.getString(2));
            vo.sett_Salary(rs.getString(3));
            
            list1.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist1 fail");         
    }finally{          
        db_close();
    }      
    return list1;
}//getwithSearchlist1



/**
* 서브쿼리를 이용하여 아동 '그그그'와 같은 반인 아동의 이름을 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist2(){
    ArrayList<withVO> list2 = new ArrayList<withVO>();
    try{//실행
        String sql ="select k_Tclass, k_Name from KID where k_Tclass IN (select k_Tclass from KID where k_Name='그그그') ";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setk_Tclass(rs.getString(1));
            vo.setk_Name(rs.getString(2));
            
            list2.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist2 fail");         
    }finally{          
        db_close();
    }      
    return list2;
}//getwithSearchlist2



/**
* 모든 아동들의 성별을 그룹화하고 평균 나이를 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist3(){
    ArrayList<withVO> list3 = new ArrayList<withVO>();
    try{//실행
        String sql ="select k_gender, avg(k_age) "
        		+ "from KID "
        		+ "group by k_gender ";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setk_Gender(rs.getString(1));
            vo.setk_Age(rs.getString(2));
            
            list3.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist3 fail");         
    }finally{          
        db_close();
    }      
    return list3;
}//getwithSearchlist3



/**
* 선생님테이블에서 직위가 교사인 인원수와, 교사의 평균 급여를 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist4(){
    ArrayList<withVO> list4 = new ArrayList<withVO>();
    try{//실행
        String sql ="select count(t_posi), avg(t_salary) "
        		+ "from TEACHER "
        		+ "where t_salary IN ( select t_salary from teacher where t_posi='교사') ";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.sett_Posi(rs.getString(1));
            vo.sett_Salary(rs.getString(2));
            
            list4.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist4 fail");         
    }finally{          
        db_close();
    }      
    return list4;
}//getwithSearchlist4


/**
* 모든 아동들의 반으로 그룹화하고, 각 반의 평균 나이 검색.
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist5(){
    ArrayList<withVO> list5 = new ArrayList<withVO>();
    try{//실행
        String sql ="select k_tclass, avg(k_age) "
        		+ "from KID "
        		+ "group by k_tclass";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setk_Tclass(rs.getString(1));
            vo.setk_Age(rs.getString(2));
            
            list5.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist5 fail");         
    }finally{          
        db_close();
    }      
    return list5;
}//getwithSearchlist5


/**
* 모든 선생님의 직위를 그룹화하고, 월급의 평균 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist6(){
    ArrayList<withVO> list6 = new ArrayList<withVO>();
    try{//실행
        String sql ="select t_posi, avg(t_salary) "
        		+ "from TEACHER "
        		+ "group by t_posi";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.sett_Posi(rs.getString(1));
            vo.sett_Salary(rs.getString(2));
                       
            list6.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist6 fail");         
    }finally{          
        db_close();
    }      
    return list6;
}//getwithSearchlist6



/**
* 모든 아동들에 대해서 아동들이 속한 반별로 그룹화하고, 평균나이가 6세 이상인 아동반에 대해서 평균나이, 최대나이를 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist7(){
    ArrayList<withVO> list7 = new ArrayList<withVO>();
    try{//실행
        String sql ="select k_tclass, avg(k_age), max(k_age) as k_Age_max "
        		+ "from KID "
        		+ "group by k_tclass having avg(k_age) >= 6";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setk_Tclass(rs.getString(1));
            vo.setk_Age(rs.getString(2));
            vo.setk_Age_max(rs.getString(3));
            
            list7.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist7 fail");         
    }finally{          
        db_close();
    }      
    return list7;
}//getwithSearchlist7




/**
* 모든 아동에 대해서 아동의 이름과 해당반, 해당반의 선생님 이름을 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist8(){
    ArrayList<withVO> list8 = new ArrayList<withVO>();
    try{//실행
        String sql ="select k_name, t_kclass, t_name "
        		+ "from KID k,TEACHER t "
        		+ "where k.k_tclass = t.t_kclass";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setk_Name(rs.getString(1));
            vo.sett_Kclass(rs.getString(2));
            vo.sett_Name(rs.getString(3));
            
            list8.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist8 fail");         
    }finally{          
        db_close();
    }      
    return list8;
}//getwithSearchlist8



/**
* 병점 거주하는 학부모와 해당아동의 이름을 오름차순으로 중복제거 후 정렬하여 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist9(){
    ArrayList<withVO> list9 = new ArrayList<withVO>();
    try{//실행
        String sql ="select distinct p_name, k_name "
        		+ "from PARENT p, KID k "
        		+ "where p.p_ju2=k.k_pju2 and p.p_ad = '병점'";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setp_Name(rs.getString(1));
            vo.setk_Name(rs.getString(2));
            
            list9.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist9 fail");         
    }finally{          
        db_close();
    }      
    return list9;
}//getwithSearchlist9



/**
* 학부모 연락처와 아동 연락처 중, 공통된 연락처인 경우만 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist10(){
    ArrayList<withVO> list10 = new ArrayList<withVO>();
    try{//실행
        String sql ="select p_phone, k_phone "
        		+ "from PARENT p "
        		+ "INNER JOIN KID k "
        		+ "on p.p_phone = k.k_phone";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setp_Phone(rs.getString(1));
            vo.setk_Phone(rs.getString(2));
            
            list10.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist10 fail");         
    }finally{          
        db_close();
    }      
    return list10;
}//getwithSearchlist10



/**
*  좌 행엔 모든 학부모 연락처를 검색하고,
*  우 행엔 학부모 연락처와 아동 연락처 중 공통된 부분만 검색(아닌 경우 NULL)
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist11(){
    ArrayList<withVO> list11 = new ArrayList<withVO>();
    try{//실행
        String sql ="select p_phone, k_phone "
        		+ "from PARENT p "
        		+ "LEFT OUTER JOIN KID k "
        		+ "on p.p_phone = k.k_phone";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setp_Phone(rs.getString(1));
            vo.setk_Phone(rs.getString(2));
            
            list11.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist11 fail");         
    }finally{          
        db_close();
    }      
    return list11;
}//getwithSearchlist11




/**
*  좌 행엔 학부모 연락처와 아동 연락처 중 공통된 부분을 검색하고(아닌 경우NULL),
*  우 행엔 모든 학부모 연락처를 검색
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist12(){
    ArrayList<withVO> list12 = new ArrayList<withVO>();
    try{//실행
        String sql ="select p_phone, k_phone "
        		+ "from PARENT p "
        		+ "RIGHT OUTER JOIN KID k "
        		+ "on p.p_phone = k.k_phone";
        System.out.println("sql = " + sql);
        st = con.createStatement();
        rs = st.executeQuery(sql);
        while(rs.next()){
        	withVO vo = new withVO();
            vo.setp_Phone(rs.getString(1));
            vo.setk_Phone(rs.getString(2));
            
            list12.add(vo);
        }
    }catch(Exception e){           
        System.out.println(e+"=> getwithSearchlist12 fail");         
    }finally{          
        db_close();
    }      
    return list12;
}//getwithSearchlist12


/**
* 아동,학부모테이블의 연락처를 아우터조인하는 메서드 작성
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist13(){
ArrayList<withVO> list13 = new ArrayList<withVO>();
try{//실행
 String sql ="select p_Phone,k_Phone "
 		+ "from PARENT p "
 		+ "FULL OUTER JOIN "
 		+ "KID k "
 		+ "ON p.p_Phone=k.k_Phone ";
 //모든 레코드 검색
     sql +="order by p_Phone";
 System.out.println("sql = " + sql);
 st = con.createStatement();
 rs = st.executeQuery(sql);
 while(rs.next()){
	 withVO vo = new withVO();
     
     vo.setp_Phone(rs.getString(1));
     vo.setk_Phone(rs.getString(2));
     
     list13.add(vo);
 }
}catch(Exception e){           
 System.out.println(e+"=> getwithSearchlist13 fail");         
}finally{          
 db_close();
}      
return list13;
}//getwithSearchlist13

/**
* 선생님,학부모테이블의 연락처를 아우터조인하는 메서드 작성
* (검색필드와 검색단어가 들어왔을때는 where를 이용하여 검색해준다.)
**/
public ArrayList<withVO> getwithlist14(){
ArrayList<withVO> list14 = new ArrayList<withVO>();
try{//실행
 String sql ="select k_tclass, k_name, t_name, t_kclass "
 		+ "from teacher t "
 		+ "FULL OUTER JOIN "
 		+ "KID k "
 		+ "ON t.t_Kclass=k.k_Tclass ";
 //모든 레코드 검색
     sql +="order by k_tclass";
 System.out.println("sql = " + sql);
 st = con.createStatement();
 rs = st.executeQuery(sql);
 while(rs.next()){
	 withVO vo = new withVO();
     
     vo.setk_Tclass(rs.getString(1));
     vo.setk_Name(rs.getString(2));
     vo.sett_Name(rs.getString(3));
     vo.sett_Kclass(rs.getString(4));
     
     list14.add(vo);
 }
}catch(Exception e){           
 System.out.println(e+"=> getwithSearchlist14 fail");         
}finally{          
 db_close();
}      
return list14;
}//getwithSearchlist14





}